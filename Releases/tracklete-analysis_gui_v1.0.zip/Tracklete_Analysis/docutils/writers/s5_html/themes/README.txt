Except where otherwise noted (default/iepngfix.htc), all files in this
directory have been released into the Public Domain.

These files are based on files from S5 1.1, released into the Public
Domain by Eric Meyer.  For further details, please see
http://www.meyerweb.com/eric/tools/s5/credits.html.
